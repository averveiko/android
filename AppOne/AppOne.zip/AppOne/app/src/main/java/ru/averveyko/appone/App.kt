package ru.averveyko.appone

import android.app.Application

class App : Application() {

    /*
     Запуск приложения. Тут можно инициализировать какие-то классы которые нужны на всем протяжении
     жизни приложения: реклама, и т.д.
     */
    override fun onCreate() {
        super.onCreate()
    }
}